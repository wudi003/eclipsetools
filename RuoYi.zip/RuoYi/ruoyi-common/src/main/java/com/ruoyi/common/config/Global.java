package com.ruoyi.common.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;

/**
 * 全局配置类
 * 
 * @author ruoyi
 */
@Component
@ConfigurationProperties(prefix = "ruoyi")
public class Global
{
    /** 项目名称 */
    private static String name;

    /** 版本 */
    private static String version;

    /** 版权年份 */
    private static String copyrightYear;

    /** 实例演示开关 */
    private static boolean demoEnabled;

    /** 上传路径 */
    private static String profile;

    /** 获取地址开关 */
    private static boolean addressEnabled;
    
    /** 菜单导航显示风格 */
    private static String menuStyle="default";
    
    /**发布的域名  */
    private static String publisAddress;
    /**
     * webim是否启用开管
     */
    private static boolean webimEnabled=true;
    
    private static boolean oauth2LoginEnabled=true;

    public static String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        Global.name = name;
    }

    public static String getVersion()
    {
        return version;
    }

    public void setVersion(String version)
    {
        Global.version = version;
    }

    public static String getCopyrightYear()
    {
    	if (StringUtils.isBlank(copyrightYear)) {
			copyrightYear = DateUtils.getYear();
		}
		return copyrightYear;
    }

    public void setCopyrightYear(String copyrightYear)
    {
        Global.copyrightYear = copyrightYear;
    }

    public static boolean isDemoEnabled()
    {
        return demoEnabled;
    }

    public void setDemoEnabled(boolean demoEnabled)
    {
        Global.demoEnabled = demoEnabled;
    }

    public static String getProfile()
    {
        return profile;
    }

    public void setProfile(String profile)
    {
        Global.profile = profile;
    }

    public static boolean isAddressEnabled()
    {
        return addressEnabled;
    }

    public void setAddressEnabled(boolean addressEnabled)
    {
        Global.addressEnabled = addressEnabled;
    }
    
    public static String getMenuStyle()
    {
        return menuStyle;
    }

    public void setMenuStyle(String menuStyle)
    {
        Global.menuStyle = menuStyle;
    }

    /**
     * 获取头像上传路径
     */
    public static String getAvatarPath()
    {
        return getProfile() + "/avatar";
    }

    /**
     * 获取下载路径
     */
    public static String getDownloadPath()
    {
        return getProfile() + "/download/";
    }

    /**
     * 获取上传路径
     */
    public static String getUploadPath()
    {
        return getProfile() + "/upload";
    }
    
    public static String getPublisAddress() {
		return publisAddress;
	}

	public void setPublisAddress(String publisAddress) {
		Global.publisAddress = publisAddress;
	}

	public static boolean webimEnabled() {
		return Global.webimEnabled;
	}
	
	
	public static boolean isOauth2LoginEnabled() {
		return oauth2LoginEnabled;
	}

	@Bean
	@ConditionalOnMissingBean(WebimAutoEnabled.class)
	public void setWebimEnabled() {
		Global.webimEnabled = false;
	}
	
	@Bean
	@ConditionalOnMissingBean(Oauth2LoginConfigService.class)
	public void setOauth2LoginConfigService() {
		Global.oauth2LoginEnabled = false;
	}
	
	
}

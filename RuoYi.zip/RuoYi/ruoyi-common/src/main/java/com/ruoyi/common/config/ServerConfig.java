package com.ruoyi.common.config;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;

/**
 * 服务相关配置
 * 
 * @author ruoyi
 *
 */
@Component
public class ServerConfig
{
    /**
     * 获取完整的请求路径，包括：域名，端口，上下文访问路径
     * 
     * @return 服务地址
     */
    public String getUrl()
    {
        HttpServletRequest request = ServletUtils.getRequest();
        return getDomain(request);
    }

    public static String getDomain(HttpServletRequest request)
    {
        StringBuffer url = request.getRequestURL();
        String contextPath = request.getServletContext().getContextPath();
         url.delete(url.length() - request.getRequestURI().length(), url.length()).append(contextPath);
         if(StringUtils.startsWith(url, "http://")&&StringUtils.endsWith(url, ":443")) {
        	 url.delete(url.indexOf(":443"), url.length());
        	 url.replace(0, "http://".length(), "https://"); 
         }
         return url.toString();
    }
    
    public static String getWebSocketDomain(HttpServletRequest request) {
    	String domain=getDomain(request);
    	if(StringUtils.startsWith(domain, "http://")) {
    		return domain.replaceAll("http://", "ws://");
    	}else if(StringUtils.startsWith(domain, "https://")) {
    		return domain.replaceAll("https://", "wss://");
    	}
		return domain;
    	
    }
}

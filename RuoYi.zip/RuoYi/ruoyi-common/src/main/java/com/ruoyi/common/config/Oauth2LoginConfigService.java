package com.ruoyi.common.config;

import java.util.List;

import com.ruoyi.common.core.domain.Oauth2LoginConfig;

public interface Oauth2LoginConfigService {
	
	List<Oauth2LoginConfig> loginConfig(String authAreaId);
	
	void registerauthOauthUser(String uuid,String loginname,String username);

}

package com.ruoyi.common.core.domain;

import java.io.Serializable;

public class Oauth2LoginConfig implements Serializable {
	private static final long serialVersionUID = -6595368497565102610L;
	
	private String imgSrc;
	private String hrefUrl;
	private String hrefText;
	
	public Oauth2LoginConfig(String imgSrc, String hrefUrl, String hrefText) {
		super();
		this.imgSrc = imgSrc;
		this.hrefUrl = hrefUrl;
		this.hrefText = hrefText;
	}
	
	public Oauth2LoginConfig() {
		super();
	}

	public String getImgSrc() {
		return imgSrc;
	}
	public void setImgSrc(String imgSrc) {
		this.imgSrc = imgSrc;
	}
	public String getHrefUrl() {
		return hrefUrl;
	}
	public void setHrefUrl(String hrefUrl) {
		this.hrefUrl = hrefUrl;
	}
	public String getHrefText() {
		return hrefText;
	}
	public void setHrefText(String hrefText) {
		this.hrefText = hrefText;
	}
	
	

}

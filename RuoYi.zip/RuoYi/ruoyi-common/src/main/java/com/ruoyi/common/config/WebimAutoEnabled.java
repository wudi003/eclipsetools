package com.ruoyi.common.config;

public interface WebimAutoEnabled {

}

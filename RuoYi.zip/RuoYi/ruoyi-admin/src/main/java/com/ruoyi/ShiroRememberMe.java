package com.ruoyi;

import java.security.NoSuchAlgorithmException;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.apache.shiro.codec.Base64;

import com.ruoyi.common.utils.StringUtils;

public class ShiroRememberMe {

	public static void main(String[] args) throws NoSuchAlgorithmException {
		//KeyGenerator keygen = KeyGenerator.getInstance("AES");
		//SecretKey deskey = keygen.generateKey();
		//System.out.println(Base64.encodeToString(deskey.getEncoded()));
		String s="        真烟流动        ";
		System.out.println("---"+StringUtils.trim(s.replaceAll("&nbsp", ""))+"---");
		System.out.println("---"+StringUtils.trim(s.replaceAll("\u00a0", ""))+"---");

	}

}

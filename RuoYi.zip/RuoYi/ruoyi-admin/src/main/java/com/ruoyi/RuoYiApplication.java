package com.ruoyi;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * 启动程序
 * 
 * @author ruoyi
 */
@EnableAsync
@SpringBootApplication
public class RuoYiApplication implements ApplicationRunner {
	
	
	public static void main(String[] args) {
		SpringApplication.run(RuoYiApplication.class, args);
		System.out.println("(♥◠‿◠)ﾉﾞ 启动成功   ლ(´ڡ`ლ)ﾞ ");
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		/*List<LinkedCaseInsensitiveMap> list= dynamicMongoTemplate.getTemplate("xayc").findAll(LinkedCaseInsensitiveMap.class,"PLM_BRANDOWNER_V");
		for (LinkedCaseInsensitiveMap map : list) {
			System.out.println(map);
			Object redisObj= dynamicRedisTemplate.getTemplate("test").opsForValue().get(map.get("BRDOWNER_ID").toString());
			System.out.println(redisObj);
		}*/
		/*System.out.println("---------------------------jdbc-----------------------------------");
		List<Map<String, Object>> ListMaps = dynamicJdbcTemplate.getTemplate("v6db").queryForList("SELECT * FROM  PLM_BRANDOWNER_V ");
		for (Map<String, Object> map : ListMaps) {
			System.out.println(map);
		}*/

		/*List<Map<String, Object>> ListMaps = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForList("SELECT * FROM  PLM_BRANDOWNER_V ");
		
		for (Map<String, Object> map : ListMaps) {
			map.put("_id", map.get("BRDOWNER_ID"));
		
			mongoTemplate.save(map, "PLM_BRANDOWNER_V");
			redisTemplate.opsForValue().set(map.get("BRDOWNER_ID").toString(), map);
		}
		
		ListMaps = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForList("SELECT * FROM PLM_ITEM_V");
		
		for (Map<String, Object> map : ListMaps) {
			map.put("_id", map.get("ITEM_ID"));
		
			mongoTemplate.save(map, "PLM_ITEM_V");
		}
		
		ListMaps = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForList("SELECT * FROM PLM_ITEM_COM_V");
		
		for (Map<String, Object> map : ListMaps) {
			map.put("_id", map.get("COM_ID").toString() + map.get("ITEM_ID"));
		
			mongoTemplate.save(map, "PLM_ITEM_COM_V");
		}
		
		ListMaps = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForList("SELECT * FROM PLM_BRAND_V");
		
		for (Map<String, Object> map : ListMaps) {
			map.put("_id", map.get("BRAND_ID"));
		
			mongoTemplate.save(map, "PLM_BRAND_V");
		}
		
		ListMaps = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForList("SELECT * FROM CO_CO_V");
		
		for (Map<String, Object> map : ListMaps) {
			map.put("_id", map.get("CO_NUM"));
			mongoTemplate.save(map, "CO_CO_V");
			
			
		}
		
		Long rowCount = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForObject("SELECT count(*) FROM  CO_CO_LINE_V ",Long.class);
		long pageSum=(rowCount-1)/50000+1;
		for (int i = 1; i < pageSum; i++) {
			ListMaps = dynamicJdbcTemplate.getJdbcTemplate("v6db").queryForList("select * from (select t.*,ROW_NUMBER() OVER() AS ROWNUM from CO_CO_LINE_V t) a where ROWNUM > "+(i-1)*5000+" and ROWNUM <="+i*5000);
			
			for (Map<String, Object> map2 : ListMaps) {
				map2.put("_id", map2.get("CO_NUM").toString()+map2.get("LINE_NUM"));
				mongoTemplate.save(map2, "CO_CO_LINE_V");
			}
		}*/
		System.out.println("操作完了");
	}
}
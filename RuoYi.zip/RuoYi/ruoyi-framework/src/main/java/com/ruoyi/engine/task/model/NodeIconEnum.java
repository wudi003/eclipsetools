package com.ruoyi.engine.task.model;

public enum NodeIconEnum {
	
	START("icon-star"),END("icon-star"),DATA_MARKET("icon-star");
	
	private NodeIconEnum(String code) {
		this.code = code;
	}
	private String code;
	public String getCode() {
		return code;
	}
	
	

}

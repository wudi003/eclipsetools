package com.ruoyi.engine.data.service;

import java.util.List;

import com.ruoyi.engine.data.domain.Product;

public interface DataFactoryProductService {
	
	public String getCode();
	
	public String getName();
	
	public List<Product> getProduct();
	
	public DynamicTemplate getDynamicTemplate(String code); 

}

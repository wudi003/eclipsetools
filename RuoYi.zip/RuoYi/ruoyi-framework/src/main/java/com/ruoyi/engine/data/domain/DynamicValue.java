package com.ruoyi.engine.data.domain;

import java.util.Map;

import org.springframework.util.LinkedCaseInsensitiveMap;

public class DynamicValue extends LinkedCaseInsensitiveMap<Object> {
	private static final long serialVersionUID = -1604499135987027447L;

	public DynamicValue() {
		super();
	}
	public DynamicValue(int initialCapacity) {
		super(initialCapacity);
	}
	public DynamicValue(Map<String, Object> rowMap) {
		this.putAll(rowMap);
	}

}

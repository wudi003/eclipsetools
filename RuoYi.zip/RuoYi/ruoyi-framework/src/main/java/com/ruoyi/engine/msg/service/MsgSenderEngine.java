package com.ruoyi.engine.msg.service;

import java.util.List;
import java.util.Map;

import com.ruoyi.engine.msg.model.MsgSenderProvider;

public interface MsgSenderEngine {
	
	MsgSender getMsgSender(String serviceName);
	
	Map<String, MsgSender> getMsgSender();
	
	List<MsgSenderProvider> getMsgSenderProvider();

}

package com.ruoyi.engine.page.service;

public interface DynamicPagesHandlerService {
	
	String getPage(String param);
	
	String prefix();
}

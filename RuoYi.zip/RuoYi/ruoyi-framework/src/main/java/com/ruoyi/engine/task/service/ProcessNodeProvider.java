package com.ruoyi.engine.task.service;

import java.util.List;

import com.ruoyi.engine.task.model.ProcessNode;

public interface ProcessNodeProvider {
	
	List<ProcessNode> getNodes();

}

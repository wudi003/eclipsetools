package com.ruoyi.engine.task.service;

import java.util.Map;

public interface ProcessNodeHandle {
	
	Map<String, ? extends Object> execute(Map<String, ? extends Object> context);

}

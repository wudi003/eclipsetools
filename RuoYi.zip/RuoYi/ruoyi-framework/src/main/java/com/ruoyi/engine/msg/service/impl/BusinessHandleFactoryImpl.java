package com.ruoyi.engine.msg.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.msg.service.BusinessHandle;
import com.ruoyi.engine.msg.service.BusinessHandleFactory;

@Component
public class BusinessHandleFactoryImpl implements BusinessHandleFactory {

	@Autowired
    private ApplicationContext context;
	@Override
	public BusinessHandle getHandle(String handleName) {
		return this.context.getBean(handleName, BusinessHandle.class);
	}

}

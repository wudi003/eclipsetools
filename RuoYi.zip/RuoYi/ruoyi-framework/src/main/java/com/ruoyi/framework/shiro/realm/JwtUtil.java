package com.ruoyi.framework.shiro.realm;

import java.util.Date;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

/**
 * @author huwen
 */
public class JwtUtil {
	/**
	 * 设置过期时间7天
	 */
	public static final Long EXPIRE_TIME =7* 1000 * 60 * 60 * 24L;
	/**
	 * 有效时间 5分钟
	 */
	public static final Long PERIOD_TIME = 1000 * 60*5L;
	/**
	 * 设置密钥
	 */
	public static final String SECRET = "shiro+jwt";
	public static final String CLAIM_FILED = "username";

	/**
	 * 根据用户名创建一个token
	 * @param username 用户名
	 * @return 返回的token字符串
	 */
	public static String createToken(String username) {
		return createToken(username, EXPIRE_TIME);
	}

	public static String createToken(String username, long expireTime) {
		return createToken(CLAIM_FILED, username, SECRET, expireTime);
	}

	public static String createToken(String filedkey, String username, String secret, long expireTime) {
		//将当前时间的毫秒数和设置的过期时间相加生成一个新的时间
		Date date = new Date(System.currentTimeMillis() + expireTime);
		//由密钥创建一个指定的算法
		Algorithm algorithm = Algorithm.HMAC256(secret);
		return JWT.create()
				//附带username信息
				.withClaim(filedkey, username)
				//附带过期时间
				.withExpiresAt(date)
				//使用指定的算法进行标记
				.sign(algorithm);
	}

	public static String createToken(String claimfiled, String username, String secret) {
		return createToken(claimfiled, username, secret, EXPIRE_TIME);
	}

	/**
	 * 验证token是否正确
	 * @param token 前端传过来的token
	 * @param username 用户名
	 * @return 返回boolean
	 */
	public static boolean verify(String token, String username) {
		//获取算法
		Algorithm algorithm = Algorithm.HMAC256(SECRET);
		//生成JWTVerifier
		JWTVerifier verifier = JWT.require(algorithm).withClaim(CLAIM_FILED, username).build();
		//验证token
		verifier.verify(token);
		return true;
	}
	public static boolean verify(String token) {
		return verify(token, SECRET, PERIOD_TIME);
	}
	public static boolean verify(String token,long periodTime) {
		return verify(token, SECRET, periodTime);
	}
	public static boolean verify(String token, String secret, long periodTime) {
		try {
			//获取算法
			Algorithm algorithm = Algorithm.HMAC256(secret);
			//生成JWTVerifier
			JWTVerifier verifier = JWT.require(algorithm).build();
			//验证token
			DecodedJWT jwt = verifier.verify(token);
			if ((jwt.getExpiresAt().getTime() - jwt.getIssuedAt().getTime()) <= periodTime) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	/**
	 * 从token中获得username，无需secret
	 * @param token token
	 * @return username
	 */
	public static String getClaimValue(String claimfiled, String token) {
		return getClaimValue(claimfiled, token, EXPIRE_TIME);
	}

	/**
	 * 验证签发的有效期
	 *@param claimfiled
	 *@param token
	 *@param periodTime
	 *@return
	 *@exception
	 */
	public static String getClaimValue(String claimfiled, String token, String secret, long periodTime) {
		try {
			Algorithm algorithm = Algorithm.HMAC256(secret);
			//生成JWTVerifier
			JWTVerifier verifier = JWT.require(algorithm).build();
			//验证token
			DecodedJWT jwt = verifier.verify(token);
			return jwt.getClaim(claimfiled).asString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getClaimValue(String claimfiled, String token, long periodTime) {
		return getClaimValue(claimfiled, token, SECRET, periodTime);
	}

	public static String getUsername(String token) {
		return getClaimValue(CLAIM_FILED, token);
	}

	public static void main(String[] args) throws InterruptedException {
		String xx = createToken("xasxueli", 1000);
		System.out.println(xx);
		System.out.println(xx.length());
		Thread.sleep(5000);
		//System.out.println(verify(xx, "xasxueli"));
		System.out.println(getUsername(xx));
	}
}
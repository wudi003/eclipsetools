package com.ruoyi.engine.msg.model;

public enum MsgRoleEnum {
	SYSTEM("system", "系统管理员"),BUSINESS("business", "业务管理员"),MEMBER("member", "成员"),WATCHDOG("watchdog", "值班员");  
	
	private MsgRoleEnum(String code, String name) {
		this.code = code;
		this.name = name;
	}
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public static MsgRoleEnum[] getTypes(){
		return  MsgRoleEnum.values();
	}
	
	public static MsgRoleEnum[] getWebTypes(){
		return  new MsgRoleEnum[] {MEMBER,WATCHDOG};
	}

}

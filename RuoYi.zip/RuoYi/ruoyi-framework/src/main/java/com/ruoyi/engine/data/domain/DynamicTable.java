package com.ruoyi.engine.data.domain;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class DynamicTable implements Serializable {
	private static final long serialVersionUID = -7351344287655689443L;

    /** 表名称 */
    private String tableName;

    /** 表类型 */
    private String tableType;
    
    /** 表描述 */
    private String remarks;
    
    private String dbUrl;
}

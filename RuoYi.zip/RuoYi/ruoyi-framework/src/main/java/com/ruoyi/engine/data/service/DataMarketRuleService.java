package com.ruoyi.engine.data.service;

import java.util.List;
import java.util.Map;

import com.ruoyi.engine.data.domain.MarketRuleWhere;

public interface DataMarketRuleService {
	
	public String getCode();
	
	public String getName();
	
	public List<MarketRuleWhere> getRuleNames();
	
	public List<MarketRuleWhere> getRuleWheres(String ruleName);
	
	public List<Map<String,Object>> getRuleByWhere(Map<String, ? extends Object> row,String ruleName,String where);

}

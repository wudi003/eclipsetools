package com.ruoyi.engine.data.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.data.domain.EntityPagesRequest;
import com.ruoyi.engine.data.service.EntityPagesRequestProviderService;
import com.ruoyi.engine.data.service.PagesRequestFactoryService;
@Component
public class PagesRequestFactoryServiceImpl implements PagesRequestFactoryService {
	
	
	@Autowired
    private ApplicationContext context;

	@Override
	public List<EntityPagesRequest> getEntityPagesRequest(Long entityId) {
		List<EntityPagesRequest> reqs=new ArrayList<EntityPagesRequest>();
		Collection<EntityPagesRequestProviderService> services= context.getBeansOfType(EntityPagesRequestProviderService.class).values();
		for (EntityPagesRequestProviderService s : services) {
			reqs.addAll(s.getEntityPagesRequest(entityId));
		}
		return reqs;
	}

}

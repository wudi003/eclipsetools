package com.ruoyi.framework.shiro.token;

public class UsernamePasswordToken extends org.apache.shiro.authc.UsernamePasswordToken {
	private static final long serialVersionUID = 1L;
	private String authcType; //登录方式 微信

	public UsernamePasswordToken(String username,String authcType) {
		super(username, "UUID!QAZ@WSX#EDC", false, null);
		this.authcType=authcType;
	}

	public UsernamePasswordToken() {
		super();
	}

	public UsernamePasswordToken(String username, String password, Boolean rememberMe) {
		super(username, password, rememberMe);
	}

	public String getAuthcType() {
		return authcType;
	}

	

}

package com.ruoyi.framework.shiro.authc;

import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.credential.SimpleCredentialsMatcher;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.util.ByteSource;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.shiro.token.UsernamePasswordToken;

public class CustomCredentialsMatcher extends SimpleCredentialsMatcher {
	@Override
	public boolean doCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) {
		UsernamePasswordToken upToken = (UsernamePasswordToken) token;
		SimpleAuthenticationInfo ainfo = (SimpleAuthenticationInfo) info;
		String cpassword = new String(upToken.getPassword());
		String npassword=(String) ainfo.getCredentials();
		String username=(String) upToken.getUsername();
		String password = null;
		if (StringUtils.length(cpassword)==28&&StringUtils.length(npassword)==28) {
			password=cpassword;
		} else if (ainfo.getCredentialsSalt() != null) {
			password =new Md5Hash(username + password +new String(ainfo.getCredentialsSalt().getBytes())).toHex();
		} else {
			//兼容OA密码加密模式
			//password = passwordEncrypt(cpassword);
		}

		return StringUtils.equals(password, npassword);
	}
	
	
}

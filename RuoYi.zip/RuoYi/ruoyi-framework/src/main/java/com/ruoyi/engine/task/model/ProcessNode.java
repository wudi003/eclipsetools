package com.ruoyi.engine.task.model;

import java.io.Serializable;
import java.util.List;

public class ProcessNode implements Serializable {
	private static final long serialVersionUID = 8814749889699447041L;
	private String type;
	private String name;
	private String handle;
	private List<NodeParam> params;
	private NodeIconEnum icon;
	public ProcessNode(String type, String name, String handle, List<NodeParam> params, NodeIconEnum icon) {
		super();
		this.type = type;
		this.name = name;
		this.handle = handle;
		this.params = params;
		this.icon = icon;
	}
	public String getType() {
		return type;
	}
	public String getName() {
		return name;
	}
	public String getHandle() {
		return handle;
	}
	public List<NodeParam> getParams() {
		return params;
	}
	public NodeIconEnum getIcon() {
		return icon;
	}
	
	
}

package com.ruoyi.engine.task.model;

public enum ParamModelEnum {
	
	MODE_IN("modeIn", "输入参数"),MODE_OUT("modeOut", "输出参数");
	
	private ParamModelEnum(String code, String name) {
		this.code = code;
		this.name = name;
	}
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}

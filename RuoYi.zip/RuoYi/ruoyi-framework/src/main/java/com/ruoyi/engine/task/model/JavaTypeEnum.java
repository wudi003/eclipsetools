package com.ruoyi.engine.task.model;

import java.math.BigDecimal;
import java.util.Date;

public enum JavaTypeEnum {
	
	LONG("Long", "Long",Long.class),
	STRING("String", "String",String.class),
	INTEGER("Integer", "Integer",Integer.class),
	DOUBLE("Double", "Double",Double.class),
	BIG_DECIMAL("BigDecimal", "BigDecimal",BigDecimal.class),
	DATE("Date", "Date",Date.class),
	BOOLEAN("Boolean", "Boolean",Boolean.class),
	
	;
	
	private JavaTypeEnum(String code, String name,Class<?> className) {
		this.code = code;
		this.name = name;
		this.className=className;
	}
	private String code;
	private String name;
	private Class<?> className;
	public String getCode() {
		
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Class<?> getClassName() {
		return className;
	}
	public void setClassName(Class<?> className) {
		this.className = className;
	}

}

package com.ruoyi.engine.jms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.jms.model.JmsCustomer;
import com.ruoyi.engine.jms.service.JmsCustomerFactory;
import com.ruoyi.engine.jms.service.JmsCustomerHandle;
import com.ruoyi.engine.jms.service.JmsCustomerHandleProvider;

@Component
public class JmsCustomerFactoryImpl implements JmsCustomerFactory {
	
	@Autowired
    private ApplicationContext context;

	@Override
	public List<JmsCustomer> customers() {
		List<JmsCustomer> customers=new ArrayList<>();
		Map<String, JmsCustomerHandleProvider> hpMap= context.getBeansOfType(JmsCustomerHandleProvider.class);
		for (JmsCustomerHandleProvider hp : hpMap.values()) {
			customers.addAll(hp.customers());
		}
		
		return customers;
	}

	@Override
	public JmsCustomerHandle process(String servicename) {
		return context.getBean(servicename, JmsCustomerHandle.class);
	}

}

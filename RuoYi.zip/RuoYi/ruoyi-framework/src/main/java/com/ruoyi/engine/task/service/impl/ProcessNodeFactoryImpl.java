package com.ruoyi.engine.task.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.task.model.ProcessNode;
import com.ruoyi.engine.task.service.ProcessNodeFactory;
import com.ruoyi.engine.task.service.ProcessNodeHandle;
import com.ruoyi.engine.task.service.ProcessNodeProvider;

@Component
public class ProcessNodeFactoryImpl implements ProcessNodeFactory {
	
	private final Map<String, ProcessNode> processNodeMap = new HashedMap<>(); 

	@Autowired
    private ApplicationContext context;
	@Override
	public List<ProcessNode> getNodes() {
		List<ProcessNode> nodes=new ArrayList<>();
		Map<String, ProcessNodeProvider> providerMap=this.context.getBeansOfType(ProcessNodeProvider.class);
		for (ProcessNodeProvider provider : providerMap.values()) {
			nodes.addAll(provider.getNodes());
		}
		for (ProcessNode processNode : nodes) {
			processNodeMap.put(processNode.getType(), processNode);
		}
		return nodes;
	}

	@Override
	public ProcessNodeHandle handle(String handleName) {
		return context.getBean(handleName, ProcessNodeHandle.class);
	}

	@Override
	public ProcessNode node(String type) {
		return processNodeMap.get(type);
	}

}

package com.ruoyi.engine.task.service;

import java.util.List;

import com.ruoyi.engine.task.model.ProcessNode;

public interface ProcessNodeFactory {
	
	List<ProcessNode> getNodes();
	
	ProcessNode node(String type);
	
	ProcessNodeHandle handle(String handleName);

}

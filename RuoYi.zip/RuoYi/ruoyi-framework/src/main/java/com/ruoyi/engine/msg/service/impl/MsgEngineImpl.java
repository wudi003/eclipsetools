package com.ruoyi.engine.msg.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.msg.model.MsgResult;
import com.ruoyi.engine.msg.service.IMsgDispatcher;
import com.ruoyi.engine.msg.service.IMsgEngine;

@Component
public class MsgEngineImpl implements IMsgEngine {

	@Autowired
	private ApplicationContext context;

	@Override
	public MsgResult send(String serviceCode,String serviceName,String handle,String signature, Map<String, ? extends Object> fields) {
		Map<String, IMsgDispatcher> dispatcher = context.getBeansOfType(IMsgDispatcher.class);
		for (IMsgDispatcher dp : dispatcher.values()) {
			MsgResult result=dp.getMsgDispatcher(serviceCode,serviceName,handle,signature, fields);
			if(!result.isSuccess()) {
				return result;
			}
		}
		return MsgResult.success();

	}

	

}

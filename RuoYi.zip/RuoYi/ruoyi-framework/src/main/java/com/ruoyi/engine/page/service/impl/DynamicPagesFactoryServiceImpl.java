package com.ruoyi.engine.page.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.page.service.DynamicPagesFactoryService;
import com.ruoyi.engine.page.service.DynamicPagesHandlerService;

@Component
public class DynamicPagesFactoryServiceImpl implements DynamicPagesFactoryService {
	@Autowired
    private ApplicationContext context;

	@Override
	public Map<String, DynamicPagesHandlerService> Handlers() {
		return context.getBeansOfType(DynamicPagesHandlerService.class);
	}
	
	
	

}

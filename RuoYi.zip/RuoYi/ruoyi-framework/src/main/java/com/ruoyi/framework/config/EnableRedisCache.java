package com.ruoyi.framework.config;

public interface EnableRedisCache {

}

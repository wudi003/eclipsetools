package com.ruoyi.engine.page.config;

import java.util.Map;

import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.spring5.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.templateresource.ITemplateResource;
import org.thymeleaf.templateresource.StringTemplateResource;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.engine.page.service.DynamicPagesFactoryService;
import com.ruoyi.engine.page.service.DynamicPagesHandlerService;

public class MySpringResourceTemplateResolver extends SpringResourceTemplateResolver {
	
	private DynamicPagesFactoryService dynamicPagesFactoryService;

	public MySpringResourceTemplateResolver(DynamicPagesFactoryService dynamicPagesFactoryService) {
		super();
		this.dynamicPagesFactoryService = dynamicPagesFactoryService;
	}

	@Override
	protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding,
			Map<String, Object> templateResolutionAttributes) {
		for (DynamicPagesHandlerService handler : dynamicPagesFactoryService.Handlers().values()) {
			if(StringUtils.startsWith(resourceName, handler.prefix())&&StringUtils.endsWith(resourceName, ".html")) {
				String param=resourceName.replaceAll(handler.prefix(), "").replaceAll(".html", "");
				
				String content = handler.getPage(param);
				return new StringTemplateResource(content);
			}
		}
		
	   return super.computeTemplateResource(configuration, ownerTemplate, template, resourceName, characterEncoding, templateResolutionAttributes);

	}

	

}

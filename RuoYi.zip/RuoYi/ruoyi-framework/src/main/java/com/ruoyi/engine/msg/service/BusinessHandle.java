package com.ruoyi.engine.msg.service;

import java.util.Map;

import org.springframework.ui.ModelMap;

import com.ruoyi.common.core.domain.AjaxResult;

public interface BusinessHandle {
	String execute(String signature,ModelMap mmap);

	AjaxResult execute(String signature, Map<String, ? extends Object> fields);
}

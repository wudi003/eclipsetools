package com.ruoyi.engine.data.service;

import java.util.List;

import com.ruoyi.engine.data.domain.EntityPagesRequest;

public interface EntityPagesRequestProviderService {
	public List<EntityPagesRequest> getEntityPagesRequest(Long entityId);
}

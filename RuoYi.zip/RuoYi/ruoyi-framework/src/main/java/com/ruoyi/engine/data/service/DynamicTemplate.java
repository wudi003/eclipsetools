package com.ruoyi.engine.data.service;

import java.util.Collection;
import java.util.List;

import com.ruoyi.engine.data.domain.DynamicColumn;
import com.ruoyi.engine.data.domain.DynamicTable;
import com.ruoyi.engine.data.domain.DynamicValue;
import com.ruoyi.engine.data.domain.MarketMatchParams;

public interface DynamicTemplate {
	
	public Long count(String name, MarketMatchParams params);
	
	public List<DynamicValue> queryForList(String name,MarketMatchParams params);
	public DynamicValue queryForMap(String name,MarketMatchParams params);
	public void save(DynamicValue map,String name);
	
	public List<DynamicTable> getDynamicTables(String tableName);

	public Collection<DynamicColumn> getDynamicTableColumns(String tableName);

	public <T> T getDataSource(Class<T> clazz);

}

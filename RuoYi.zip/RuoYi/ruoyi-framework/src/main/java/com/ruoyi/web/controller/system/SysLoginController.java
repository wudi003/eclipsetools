package com.ruoyi.web.controller.system;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.ruoyi.common.config.Global;
import com.ruoyi.common.config.Oauth2LoginConfigService;
import com.ruoyi.common.constant.Constants;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.IpUtils;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.shiro.realm.JwtUtil;
import com.ruoyi.framework.shiro.token.UsernamePasswordToken;
import com.ruoyi.framework.shiro.web.filter.JwtFilter;
import com.ruoyi.framework.web.service.ConfigService;
import com.ruoyi.system.utils.ConfigUtils;

import lombok.extern.slf4j.Slf4j;


/**
 * 登录验证
 * 
 * @author ruoyi
 */
@Controller
@Slf4j
public class SysLoginController extends BaseController
{
	@Autowired(required = false)
	private Oauth2LoginConfigService loginConfigService;
	@Autowired
	private ConfigService configService;
	
	private static final String SYS_SSO_OAUTH="sys.sso.oauth";
	private static final String SYS_SSO_OAUTH_DEFAULT="[]";
	
    @GetMapping("/login")
    public String login(HttpServletRequest request, HttpServletResponse response,ModelMap mmap)
    {
        // 如果是Ajax请求，返回Json字符串。
        if (ServletUtils.isAjaxRequest(request))
        {
            return ServletUtils.renderString(response, "{\"code\":\"1\",\"msg\":\"未登录或登录超时。请重新登录\"}");
        }
        mmap.put("copyrightYear", Global.getCopyrightYear());
        mmap.put("systemName", Global.getName());
        mmap.put("demoEnabled", Global.isDemoEnabled());
        
        JSONArray  loginConfigs=JSONArray.parseArray(configService.getKey(SYS_SSO_OAUTH, SYS_SSO_OAUTH_DEFAULT));
        if(Global.isOauth2LoginEnabled()&&loginConfigs.isEmpty()) {
        	mmap.put("loginConfigs", loginConfigService.loginConfig(Constants.OAUTH_AREA_ID));
        	mmap.put("oauth2LoginEnabled", Global.isOauth2LoginEnabled());
        }else if(!loginConfigs.isEmpty()) {
        	mmap.put("oauth2LoginEnabled", true);
        	mmap.put("loginConfigs", loginConfigs);
        }
        
        
        return "login";
    }
    
    @GetMapping("/ssologin")
    public void ssologin(HttpServletRequest request,HttpServletResponse response) throws IOException
    {
    	try {
    		String ssotoken = request.getParameter("ssotoken");
    		if (StringUtils.isNotBlank(ssotoken)) {
    			String username = JwtUtil.getClaimValue(ConfigUtils.getKey(JwtFilter.SYS_SSO_CLIENT_USERNAME, JwtUtil.CLAIM_FILED), ssotoken, ConfigUtils.getKey(JwtFilter.SYS_SSO_CLIENT_SECRET, JwtUtil.SECRET), JwtUtil.PERIOD_TIME);
    			if (StringUtils.isNotBlank(username)) {
    				Subject subject = SecurityUtils.getSubject();
    				UsernamePasswordToken token = new UsernamePasswordToken(username, "oauth2");
    				subject.login(token);
    				String logintoken = JwtUtil.createToken(ConfigUtils.getKey(JwtFilter.SYS_SSO_CLIENT_USERNAME, JwtUtil.CLAIM_FILED),username,IpUtils.getIpAddr(request)+ConfigUtils.getKey(JwtFilter.SYS_SSO_CLIENT_SECRET, JwtUtil.SECRET)+JwtUtil.SECRET);
    	            //令牌域名（头子跨域)
    	            response.addHeader("Access-Control-Expose-Headers","ssotoken");
    	            response.addHeader("ssotoken", logintoken);
    	            Cookie tokenCookie=new Cookie("ssotoken", logintoken);
    	            tokenCookie.setHttpOnly(true);
    	            tokenCookie.setMaxAge(JwtUtil.EXPIRE_TIME.intValue()/1000);
    	            response.addCookie(tokenCookie);
    				response.sendRedirect("/index");
    				return ;
    			}
    		}
			
		} catch (Exception e) {
			log.error("sso异常",e);
		}
    	response.sendRedirect("/login");
    }
    

    @PostMapping("/login")
    @ResponseBody
    public AjaxResult ajaxLogin(String username, String password, Boolean rememberMe,HttpServletResponse response)
    {
        UsernamePasswordToken token = new UsernamePasswordToken(username, password, rememberMe);
        Subject subject = SecurityUtils.getSubject();
        try
        {
            subject.login(token);
            String logintoken = JwtUtil.createToken(ConfigUtils.getKey(JwtFilter.SYS_SSO_CLIENT_USERNAME, JwtUtil.CLAIM_FILED),username,ConfigUtils.getKey(JwtFilter.SYS_SSO_CLIENT_SECRET, JwtUtil.SECRET)+JwtUtil.SECRET);
            //令牌域名（头子跨域)
            response.addHeader("Access-Control-Expose-Headers","ssotoken");
            response.addHeader("ssotoken", logintoken);
            Cookie tokenCookie=new Cookie("ssotoken", logintoken);
            tokenCookie.setHttpOnly(true);
            tokenCookie.setMaxAge(JwtUtil.EXPIRE_TIME.intValue()/1000);
            response.addCookie(tokenCookie);
            
            return success(logintoken);
        }
        catch (AuthenticationException e)
        {
            String msg = "用户或密码错误";
            if (StringUtils.isNotEmpty(e.getMessage()))
            {
                msg = e.getMessage();
            }
            return error(msg);
        }
    }

    @GetMapping("/unauth")
    public String unauth()
    {
        return "error/unauth";
    }
}

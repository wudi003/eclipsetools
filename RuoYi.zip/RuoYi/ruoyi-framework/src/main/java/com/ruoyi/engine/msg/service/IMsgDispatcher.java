package com.ruoyi.engine.msg.service;

import java.util.Map;

import com.ruoyi.engine.msg.model.MsgResult;

public interface IMsgDispatcher {
	MsgResult getMsgDispatcher(String serviceCode,String serviceName,String handle,String signature,Map<String, ? extends Object> fields);
}

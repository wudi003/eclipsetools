package com.ruoyi.engine.task.model;

import java.io.Serializable;

public class NodeParam implements Serializable {
	private static final long serialVersionUID = -1484188531239170336L;
	private ParamModelEnum model;
	private String code;
	private String description;
	private JavaTypeEnum javaType;
	private String defaultValue;
	public NodeParam(ParamModelEnum model, String code, String description, JavaTypeEnum javaType,String defaultValue) {
		super();
		this.model = model;
		this.code = code;
		this.description = description;
		this.javaType = javaType;
		this.defaultValue=defaultValue;
	}
	public ParamModelEnum getModel() {
		return model;
	}
	public String getCode() {
		return code;
	}
	public String getDescription() {
		return description;
	}
	public JavaTypeEnum getJavaType() {
		return javaType;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	
	
}

package com.ruoyi.engine.msg.service;

import java.util.List;

import com.ruoyi.engine.msg.model.MsgSenderProvider;

public interface IMsgSenderProvider {
	
	List<MsgSenderProvider> getSenderProvider();

}

package com.ruoyi.engine.msg.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.msg.model.MsgSenderProvider;
import com.ruoyi.engine.msg.service.IMsgSenderProvider;
import com.ruoyi.engine.msg.service.MsgSender;
import com.ruoyi.engine.msg.service.MsgSenderEngine;

@Component
public class MsgSenderEngineImpl implements MsgSenderEngine {
	
	@Autowired
    private ApplicationContext context;

	@Override
	public Map<String, MsgSender> getMsgSender() {
		return context.getBeansOfType(MsgSender.class);
	}

	@Override
	public List<MsgSenderProvider> getMsgSenderProvider() {
		List<MsgSenderProvider> prs = new ArrayList<>();
		Map<String, IMsgSenderProvider> providerMap= context.getBeansOfType(IMsgSenderProvider.class);
		for (IMsgSenderProvider pr : providerMap.values()) {
			prs.addAll(pr.getSenderProvider());
		}
		return prs;
	}

	@Override
	public MsgSender getMsgSender(String serviceName) {
		return context.getBean(serviceName,MsgSender.class);
	}

}

package com.ruoyi.engine.msg.service;

public interface BusinessHandleFactory {
	
	BusinessHandle getHandle(String handleName);

}

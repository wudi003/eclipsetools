package com.ruoyi.engine.page.service;

import java.util.Map;

public interface DynamicPagesFactoryService {
	
	
	Map<String, DynamicPagesHandlerService> Handlers();
	

}

package com.ruoyi.engine.jms.model;

import java.io.Serializable;

public class JmsCustomer implements Serializable {
	private static final long serialVersionUID = -8219000474086505812L;
	private String handleName;
	private Long customerId;
	private String name;
	public JmsCustomer(String handleName, Long customerId,String name) {
		super();
		this.handleName = handleName;
		this.customerId = customerId;
		this.name=name;
	}
	public String getHandleName() {
		return handleName;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public String getName() {
		return name;
	}
	
	
}

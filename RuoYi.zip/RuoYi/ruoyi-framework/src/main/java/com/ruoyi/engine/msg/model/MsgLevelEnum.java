package com.ruoyi.engine.msg.model;

public enum MsgLevelEnum {
	INFO("info", "所有"),ERR("error", "仅错误"),CLOSE("close", "不发送"); 
	
	private MsgLevelEnum(String code, String name) {
		this.code = code;
		this.name = name;
	}
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public static MsgLevelEnum[] getTypes(){
		return  MsgLevelEnum.values();
	}

}

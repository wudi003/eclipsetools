package com.ruoyi.engine.data.domain;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;
@Data
@ToString
public class DynamicColumn implements Serializable {
	private static final long serialVersionUID = -7351344287655689443L;

	private String columnName;
	private String typeName;
	private int columnSize;
	private int decimalDigits;
	private String isNullable; // YES/NO or "" = ie nobody knows
	private Boolean isPk = false;
	private int pkSeq;
	private String pkName;
	private String remarks;
}

package com.ruoyi.engine.data.domain;

import java.io.Serializable;

public class Product implements Serializable {
	private static final long serialVersionUID = 1953864121521896453L;
	private String code;
	private String name;
	
	
	public Product(String code, String name) {
		super();
		this.code = code;
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}

package com.ruoyi.engine.jms.service;

import java.util.List;

import com.ruoyi.engine.jms.model.JmsCustomer;

public interface JmsCustomerFactory {
	
	List<JmsCustomer> customers();
	JmsCustomerHandle process(String servicename);

}

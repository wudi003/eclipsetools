package com.ruoyi.engine.msg.model;

import java.io.Serializable;

public class MsgContext implements Serializable {
	private static final long serialVersionUID = -3997079025280713594L;
		/**消息目标 */
		private String toUser;
		/**消息级别 */
		private String msgLevel;
		/**消息角色,仅在角色模式下有效 */
		private String msgRole;
		/**消息分组,仅在分组模式下有效 */
		private String msgGroup;
		/** 标题 */
	 	private String titile;
	    /** 消息模板 */
	    private String description;
	    /** 消息链接 */
	    private String cardUrl;
	    /** 链接文字 */
	    private String cardBtn;
	    /** 消息类型 */
	    private String magType;
	    /** 发送token */
	    private String senderToken;
	    
	    private String handle;
	    
	    private String signature;

		public String getToUser() {
			return toUser;
		}

		public void setToUser(String toUser) {
			this.toUser = toUser;
		}

		public String getMsgLevel() {
			return msgLevel;
		}

		public void setMsgLevel(String msgLevel) {
			this.msgLevel = msgLevel;
		}

		public String getMsgRole() {
			return msgRole;
		}

		public void setMsgRole(String msgRole) {
			this.msgRole = msgRole;
		}

		public String getMsgGroup() {
			return msgGroup;
		}

		public void setMsgGroup(String msgGroup) {
			this.msgGroup = msgGroup;
		}

		public String getTitile() {
			return titile;
		}

		public void setTitile(String titile) {
			this.titile = titile;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getCardUrl() {
			return cardUrl;
		}

		public void setCardUrl(String cardUrl) {
			this.cardUrl = cardUrl;
		}

		public String getCardBtn() {
			return cardBtn;
		}

		public void setCardBtn(String cardBtn) {
			this.cardBtn = cardBtn;
		}

		public String getMagType() {
			return magType;
		}

		public void setMagType(String magType) {
			this.magType = magType;
		}

		public String getSenderToken() {
			return senderToken;
		}

		public void setSenderToken(String senderToken) {
			this.senderToken = senderToken;
		}

		public String getHandle() {
			return handle;
		}

		public void setHandle(String handle) {
			this.handle = handle;
		}

		public String getSignature() {
			return signature;
		}

		public void setSignature(String signature) {
			this.signature = signature;
		}
	    
	    

}

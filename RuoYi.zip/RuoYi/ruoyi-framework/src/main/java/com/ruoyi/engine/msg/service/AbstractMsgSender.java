package com.ruoyi.engine.msg.service;

import com.ruoyi.engine.msg.model.MsgContext;
import com.ruoyi.engine.msg.model.MsgResult;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public abstract class AbstractMsgSender implements MsgSender {

	@Override
	public MsgResult send(MsgContext ctx) {
		try {
			this.doSend(ctx);
			return MsgResult.success();
		} catch (Exception e) {
			log.error("消息发送异常",e);
			return MsgResult.error(e.getMessage());
		}
		
	}

	protected abstract void doSend(MsgContext ctx) throws Exception;

}

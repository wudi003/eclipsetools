package com.ruoyi.engine.page.config;

import org.springframework.boot.autoconfigure.thymeleaf.ThymeleafProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.spring5.templateresolver.SpringResourceTemplateResolver;

import com.ruoyi.engine.page.service.DynamicPagesFactoryService;

@Configuration
public class DynamicPageWebConfig {
	
	@Bean
	SpringResourceTemplateResolver mySpringResourceTemplateResolver(DynamicPagesFactoryService dynamicPagesFactoryService,ThymeleafProperties properties, ApplicationContext applicationContext) {
		MySpringResourceTemplateResolver resolver = new MySpringResourceTemplateResolver(dynamicPagesFactoryService);
		resolver.setApplicationContext(applicationContext);
		resolver.setPrefix(properties.getPrefix());
		resolver.setSuffix(properties.getSuffix());
		resolver.setTemplateMode(properties.getMode());
		if (properties.getEncoding() != null) {
			resolver.setCharacterEncoding(properties.getEncoding().name());
		}
		resolver.setCacheable(properties.isCache());
		Integer order = properties.getTemplateResolverOrder();
		if (order != null) {
			resolver.setOrder(order);
		}
		resolver.setCheckExistence(properties.isCheckTemplate());
		return resolver;
	}
	
	
}

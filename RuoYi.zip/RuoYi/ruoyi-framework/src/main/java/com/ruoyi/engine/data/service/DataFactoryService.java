package com.ruoyi.engine.data.service;

import java.util.List;

import com.ruoyi.engine.data.domain.ProductGroup;

public interface DataFactoryService {
	
	String getProductNameByKey();
	
	List<ProductGroup> getProductGroup();
	
	DynamicTemplate getDynamicTemplate(String type,String code); 

}

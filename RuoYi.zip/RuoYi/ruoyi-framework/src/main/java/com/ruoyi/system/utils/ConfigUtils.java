package com.ruoyi.system.utils;

import com.ruoyi.common.constant.Constants;
import com.ruoyi.common.core.text.Convert;
import com.ruoyi.common.utils.CacheUtils;
import com.ruoyi.common.utils.StringUtils;
/**
 * 全局参数配置
 * @author wanglp 2020-8-10 11:47:04
 */
public class ConfigUtils {
	
	
	/**
	 * 根据键名查询参数配置信息
	 * 
	 * @param configKey 参数键名
	 * @return 参数键值
	 */
	public static String getKey(String configKey) {
		return Convert.toStr(CacheUtils.get(ConfigUtils.getCacheName(), ConfigUtils.getCacheKey(configKey)));
	}

	/**
	 * 根据键名查询参数配置信息,如果值为空 则返回默认值
	 * 
	 * @param configKey 参数键名
	 * @return 参数键值
	 */
	public static String getKey(String configKey, String defaultValue) {
		String value = getKey(configKey);
		return StringUtils.isBlank(value) ? defaultValue : value;
	}
	
	
	/**
     * 获取cache name
     * 
     * @return 缓存名
     */
	public static String getCacheName()
    {
        return Constants.SYS_CONFIG_CACHE;
    }

    /**
     * 设置cache key
     * 
     * @param configKey 参数键
     * @return 缓存键key
     */
	public static String getCacheKey(String configKey)
    {
        return Constants.SYS_CONFIG_KEY + configKey;
    }

}

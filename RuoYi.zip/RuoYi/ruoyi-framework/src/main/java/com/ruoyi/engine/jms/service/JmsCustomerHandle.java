package com.ruoyi.engine.jms.service;

public interface JmsCustomerHandle {
	
	void handle(Long customerId,String data);

}

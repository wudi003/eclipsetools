package com.ruoyi.engine.data.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ruoyi.engine.data.domain.ProductGroup;
import com.ruoyi.engine.data.service.DataFactoryProductService;
import com.ruoyi.engine.data.service.DataFactoryService;
import com.ruoyi.engine.data.service.DynamicTemplate;

@Component
public class DataFactoryServiceImpl implements DataFactoryService {
	private final static ConcurrentHashMap<String, DataFactoryProductService> template_map = new ConcurrentHashMap<String, DataFactoryProductService>();
		
	@Autowired
    private ApplicationContext context;

	@Override
	public String getProductNameByKey() {
		return null;
	}
	@PostConstruct
	public void init() {
		Map<String, DataFactoryProductService> products= context.getBeansOfType(DataFactoryProductService.class);
		for (DataFactoryProductService p : products.values()) {
			template_map.put(p.getCode(), p);
		}
	}

	@Override
	public List<ProductGroup> getProductGroup() {
		List<ProductGroup> productGroups=new ArrayList<ProductGroup>();
		for (DataFactoryProductService p : template_map.values()) {
			productGroups.add(new ProductGroup(p.getCode(), p.getName(), p.getProduct()));
			template_map.put(p.getCode(), p);
		}
		return productGroups;
	}

	@Override
	public DynamicTemplate getDynamicTemplate(String type, String code) {
		return template_map.get(type).getDynamicTemplate(code);
	}

}

package com.ruoyi.framework.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.shiro.cache.ehcache.EhCacheManager;
import org.apache.shiro.config.ConfigurationException;
import org.apache.shiro.io.ResourceUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ruoyi.common.utils.StringUtils;


@Configuration(proxyBeanMethods = false)
@ConditionalOnMissingBean(EnableRedisCache.class)
public class EhCacheConfig {

	/**
	 * 缓存管理器 使用Ehcache实现
	 */
	@Bean
	public EhCacheManager getEhCacheManager(net.sf.ehcache.CacheManager ehCacheManager) {

		EhCacheManager em = new EhCacheManager();

		em.setCacheManager(ehCacheManager);
		return em;
	}

	@Bean
	net.sf.ehcache.CacheManager ehCacheManager() {
		net.sf.ehcache.CacheManager cacheManager = net.sf.ehcache.CacheManager.getCacheManager("ruoyi");
		if (StringUtils.isNull(cacheManager)) {
			InputStream in=getCacheManagerConfigFileInputStream();
			cacheManager = new net.sf.ehcache.CacheManager(in);
			IOUtils.closeQuietly(in);
		}
		System.out.println("ehcache缓存生效");
		return cacheManager;
	}

	@Bean
	public EhCacheCacheManager ehCacheCacheManager(net.sf.ehcache.CacheManager ehCacheManager) {
		return new EhCacheCacheManager(ehCacheManager);

	}

	/**
	 * 返回配置文件流 避免ehcache配置文件一直被占用，无法完全销毁项目重新部署
	 */
	protected InputStream getCacheManagerConfigFileInputStream() {
		String configFile = "classpath:ehcache/ehcache-shiro.xml";
		InputStream inputStream = null;
		try {
			inputStream = ResourceUtils.getInputStreamForPath(configFile);
			byte[] b = IOUtils.toByteArray(inputStream);
			InputStream in = new ByteArrayInputStream(b);
			return in;
		} catch (IOException e) {
			throw new ConfigurationException("Unable to obtain input stream for cacheManagerConfigFile [" + configFile + "]", e);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

}

package com.ruoyi.engine.msg.service;

import com.ruoyi.engine.msg.model.MsgContext;
import com.ruoyi.engine.msg.model.MsgResult;

public interface MsgSender {
	
	public  String name();
	
	public  String type();
	
	public MsgResult send(MsgContext ctx);

}

package com.ruoyi.engine.msg.model;

public enum MsgGroupEnum {
	MONITOR("monitor", "系统监控组"),
	ADMIN("admin", "系统管理组"),
	REPORT("report", "业务操作组"),
	DISTRIBUTION("distribution", "业务汇报组"),
	CHARGE("Charge", "业务通报组"),
	ERRORSEND("errorSend", "异常通报组"),
	operate("operate", "结果通报组");
	
	private MsgGroupEnum(String code, String name) {
		this.code = code;
		this.name = name;
	}
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public static MsgGroupEnum[] getTypes(){
		return  MsgGroupEnum.values();
	}

}

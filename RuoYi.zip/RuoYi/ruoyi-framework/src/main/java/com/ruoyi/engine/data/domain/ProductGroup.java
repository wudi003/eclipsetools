package com.ruoyi.engine.data.domain;

import java.io.Serializable;
import java.util.List;

public class ProductGroup implements Serializable {
	private static final long serialVersionUID = -9110985415300830868L;
	private String code;
	private String name;
	private List<Product> products;
	public ProductGroup(String code, String name, List<Product> products) {
		super();
		this.code = code;
		this.name = name;
		this.products = products;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	
}

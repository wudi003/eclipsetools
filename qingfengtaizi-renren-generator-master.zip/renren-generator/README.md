**项目说明** 
- 首先感谢 _人人开源团队_ 的支持。我们是 **smart-admin** 项目的代码生成器
<br> 


**如何交流、反馈、参与贡献？**
- QQ群：[![加入QQ群](https://img.shields.io/badge/QQ群-671585861-blue.svg)](http://shang.qq.com/wpa/qunwpa?idkey=b7f4442a2a6b369a55aaa549bc0fbf14c478543d6a9c8f74eafca0378fcfcf40) 或 [![加入QQ群](https://img.shields.io/badge/QQ群-671585861-blue.svg)](https://jq.qq.com/?_wv=1027&k=5bGtRX8)，推荐点击按钮入群，当然如果无法成功操作，请自行搜索群号`671585861`进行添加

- 官方网址：[https://www.smartwx.info](https://www.smartwx.info/)

- 服务器支持：[http://webcsn.com](http://webcsn.com/)

<br>

 **本地部署**
- 通过git下载源码
- 修改application.yml，更新MySQL账号和密码、数据库名称
- Eclipse、IDEA运行RenrenApplication.java，则可启动项目
- 项目访问路径：http://localhost

**演示效果图：**
![输入图片说明](https://images.gitee.com/uploads/images/2019/0112/165923_be566568_1256378.png "代码截图.png")